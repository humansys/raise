# RaiSE Security & Compliance
## Postura de Seguridad y Compliance

**VersiÃ³n:** 2.0.0  
**Fecha:** 28 de Diciembre, 2025  
**PropÃ³sito:** Documentar polÃ­ticas de seguridad, Observable Workflow y roadmap de compliance.

---

## Modelo de Amenazas

```mermaid
flowchart TB
    subgraph Threats["Vectores de Amenaza"]
        T1[InyecciÃ³n de guardrails maliciosos]
        T2[ExfiltraciÃ³n de cÃ³digo via agente]
        T3[Secrets en Golden Data]
        T4[Supply chain attack]
        T5[MCP server compromise]
    end
    
    subgraph Assets["Activos CrÃ­ticos"]
        A1[CÃ³digo fuente]
        A2[Secrets/tokens]
        A3[Guardrails de governance]
        A4[Specs/diseÃ±os]
        A5[Observable Traces]
    end
    
    subgraph Controls["Controles"]
        C1[ValidaciÃ³n de guardrails]
        C2[Local-first architecture]
        C3[Git-only distribution]
        C4[Dependency scanning]
        C5[MCP localhost-only]
    end
    
    T1 --> C1
    T2 --> C2
    T3 --> C3
    T4 --> C4
    T5 --> C5
```

---

## Activos CrÃ­ticos

| Activo | ClasificaciÃ³n | Controles |
|--------|---------------|-----------|
| CÃ³digo fuente | Confidencial | Local-first, no cloud |
| API keys/secrets | CrÃ­tico | Nunca en Golden Data |
| Guardrails (.mdc) | Interno | Versionado, code review |
| Specs/diseÃ±os | Interno | Acceso por proyecto |
| Constitution | PÃºblico | Versionado immutable |
| Observable Traces | Interno | RetenciÃ³n configurable |

---

## Vectores de Ataque y MitigaciÃ³n

### 1. InyecciÃ³n de Guardrails Maliciosos

**Amenaza:** Atacante modifica guardrails en raise-config para alterar comportamiento de agentes.

**MitigaciÃ³n:**
- Code review obligatorio para cambios en guardrails
- Branch protection en repos de config
- Firma de commits (GPG)
- Observable Workflow detecta cambios anÃ³malos
- Guardrail `guard-security-review` bloquea merges sin review

### 2. ExfiltraciÃ³n via Agente

**Amenaza:** Agente AI envÃ­a cÃ³digo/secrets a servidor externo.

**MitigaciÃ³n:**
- Arquitectura local-first (raise-mcp server local)
- No hay telemetrÃ­a hacia cloud RaiSE
- Guardrails de seguridad restringen acceso a red
- Observable Traces auditan todas las acciones del agente
- Escalation Gate para operaciones de red

### 3. Secrets en Golden Data

**Amenaza:** Usuario guarda secrets en archivos `.raise/`.

**MitigaciÃ³n:**
- `.gitignore` por default incluye patrones de secrets
- Guardrail `guard-no-secrets` detecta patterns
- ValidaciÃ³n CLI en `raise check --security`
- Pre-commit hooks opcionales
- Observable Workflow alerta si secret detectado

### 4. Supply Chain Attack

**Amenaza:** Dependencia maliciosa en raise-kit.

**MitigaciÃ³n:**
- Dependency scanning (Safety, Snyk)
- Lock files (uv.lock)
- Minimal dependencies policy
- Security advisories monitoring
- SBOM generado automÃ¡ticamente

### 5. MCP Server Compromise [NUEVO v2.1]

**Amenaza:** Atacante gana acceso al raise-mcp server.

**MitigaciÃ³n:**
- MCP server solo escucha en localhost
- Sin autenticaciÃ³n porque es local-only
- Observable Traces detectan accesos anÃ³malos
- Proceso sandboxed (sin privilegios elevados)

---

## Observable Workflow para Compliance [NUEVO v2.1]

### Arquitectura de AuditorÃ­a

```mermaid
flowchart LR
    subgraph Agents["AI Agents"]
        A[Agent Actions]
    end
    
    subgraph MCP["raise-mcp"]
        L[Log Interceptor]
    end
    
    subgraph Storage["Observable Storage"]
        T[.raise/traces/]
    end
    
    subgraph Analysis["Audit Tools"]
        R[raise audit]
        E[Export SIEM]
    end
    
    A -->|MCP calls| L
    L -->|JSONL| T
    T --> R
    R --> E
```

### QuÃ© se Registra (MELT Framework)

| Pilar | Datos Capturados | RetenciÃ³n |
|-------|------------------|-----------|
| **Metrics** | Token usage, duration, gate pass rate | 30 dÃ­as |
| **Events** | Tool calls, resource reads, escalations | 90 dÃ­as |
| **Logs** | Inputs/outputs de cada interacciÃ³n | 30 dÃ­as |
| **Traces** | Flujo completo request â†’ response | 90 dÃ­as |

### Formato de Trace

```jsonl
{
  "trace_id": "uuid",
  "session_id": "uuid",
  "timestamp": "2025-12-28T10:00:00Z",
  "action": "tool_call",
  "tool": "validate_gate",
  "input": {"gate": "gate-code", "artifact": "main.py"},
  "output": {"status": "passed", "criteria_met": 5, "criteria_total": 5},
  "duration_ms": 120,
  "actor": "agent",
  "agent_id": "cursor-ai"
}
```

### Comandos de AuditorÃ­a

```bash
# Ver traces de hoy
raise audit --date today

# Exportar para compliance
raise audit --from 2025-01-01 --to 2025-03-31 --format csv

# Buscar escalaciones
raise audit --filter "action=escalate"

# MÃ©tricas de gates
raise audit --metrics gates
```

---

## PolÃ­ticas de Datos

### Data Residency
- **Principio:** Datos nunca salen del ambiente local
- **ImplementaciÃ³n:** No hay cloud backend, todo es Git-native
- **Observable Traces:** Locales en `.raise/traces/`
- **ExcepciÃ³n:** Si usuario configura export explÃ­citamente

### Encryption

| Contexto | MÃ©todo |
|----------|--------|
| At rest | Responsabilidad del sistema host |
| In transit (Git) | SSH/HTTPS estÃ¡ndar |
| MCP (local) | No aplica (localhost) |
| Traces | Opcional: encryption at rest |

### Retention

| Dato | RetenciÃ³n Default | Configurable |
|------|-------------------|--------------|
| Observable Traces | 90 dÃ­as | SÃ­ |
| Metrics agregados | 1 aÃ±o | SÃ­ |
| Session logs | 30 dÃ­as | SÃ­ |
| Artifacts (Git) | Indefinida | Git policy |

**ConfiguraciÃ³n de retenciÃ³n:**
```yaml
# raise.yaml
observability:
  traces:
    retention_days: 90
    compression: gzip
  metrics:
    retention_days: 365
```

---

## Compliance Roadmap

| Framework | Estado | Target Date | Observable Workflow Support |
|-----------|--------|-------------|----------------------------|
| EU AI Act | ðŸ”„ En desarrollo | Q2 2025 | âœ… Trazabilidad completa |
| SOC2 Type I | ðŸ“‹ Planificado | Q3 2026 | âœ… Audit trail |
| ISO 27001 | ðŸ“‹ Futuro | 2027 | âœ… Controles documentados |
| GDPR | âœ… By design | - | âœ… No PII procesado |

### EU AI Act Alignment [DETALLADO v2.1]

RaiSE facilita cumplimiento del EU AI Act (vigente 2025):

| Requisito EU AI Act | ImplementaciÃ³n RaiSE |
|---------------------|---------------------|
| **Art. 9: Risk Management** | Guardrails con severity levels |
| **Art. 11: Technical Documentation** | Specs + Constitution versionados |
| **Art. 12: Record-keeping** | Observable Workflow traces |
| **Art. 13: Transparency** | Escalation Gates (HITL) |
| **Art. 14: Human Oversight** | Principio de HeutagogÃ­a |
| **Art. 15: Accuracy & Robustness** | Validation Gates por fase |

**Reporte de compliance:**
```bash
raise compliance --framework eu-ai-act --output report.pdf
```

---

## Audit Trail Detallado

### Eventos Auditados

| Evento | Datos | UbicaciÃ³n | Inmutabilidad |
|--------|-------|-----------|---------------|
| `raise init` | Timestamp, options, user | Observable Trace | âœ… |
| `raise pull` | Guardrails actualizados | Observable Trace | âœ… |
| `raise check` | Results, violations | Observable Trace | âœ… |
| MCP resource_read | URI, content_hash | Observable Trace | âœ… |
| MCP tool_call | Tool, input, output | Observable Trace | âœ… |
| Escalation | Reason, resolution | Observable Trace | âœ… |
| Validation Gate | Gate, status, criteria | Observable Trace | âœ… |
| Cambios en guardrails | Git diff | raise-config repo | âœ… (Git) |
| Cambios en specs | Git diff | Project repo | âœ… (Git) |

### Inmutabilidad de Traces

```mermaid
flowchart LR
    A[Trace generado] --> B[SHA-256 hash]
    B --> C[Append to JSONL]
    C --> D[Hash chain verificable]
    D --> E[Tamper detection]
```

**VerificaciÃ³n de integridad:**
```bash
raise audit --verify-integrity --from 2025-01-01
```

---

## Incident Response

### Proceso con Observable Workflow

```mermaid
flowchart LR
    A[Detectar via Traces] --> B[Evaluar severidad]
    B --> C{CrÃ­tico?}
    C -->|SÃ­| D[Escalar + Preservar traces]
    C -->|No| E[Documentar]
    D --> F[Mitigar]
    E --> F
    F --> G[Root cause via traces]
    G --> H[Post-mortem + Guardrail nuevo]
```

### ClasificaciÃ³n

| Severidad | Criterio | Response Time | AcciÃ³n Observable |
|-----------|----------|---------------|-------------------|
| CrÃ­tico | Compromiso de secrets, RCE | 4 horas | Freeze traces, notify |
| Alto | Vulnerabilidad explotable | 24 horas | Export traces afectados |
| Medio | Vulnerabilidad potencial | 7 dÃ­as | AnÃ¡lisis de traces |
| Bajo | Mejora de seguridad | Siguiente release | Nuevo guardrail |

### Forensics via Observable Workflow

```bash
# Reconstruir sesiÃ³n de incidente
raise audit --session-id <uuid> --full

# Timeline de acciones
raise audit --from "2025-01-15 14:00" --to "2025-01-15 15:00" --timeline

# Detectar anomalÃ­as
raise audit --anomaly-detection --threshold 0.95
```

---

## Secure Development

### Requisitos para Contributors

1. **Commits firmados** (GPG) para merges
2. **2FA** en cuentas de GitHub/GitLab
3. **Branch protection** habilitado
4. **Code review** obligatorio
5. **Guardrail review** para cambios en `/guardrails/`

### CI/CD Security

```yaml
# Checks obligatorios
- name: Security Scan
  run: |
    safety check
    bandit -r src/
    
- name: Dependency Audit
  run: pip-audit
  
- name: Guardrail Validation
  run: raise check --security --strict
  
- name: SBOM Generation
  run: raise sbom --output sbom.json
```

---

## Hardening Guide

### Para Organizaciones

1. **raise-config privado:** No usar repo pÃºblico para guardrails internos
2. **Branch protection:** Requerir PRs y reviews
3. **Minimal permissions:** Tokens con scope mÃ­nimo
4. **Observable Workflow activado:** `raise.yaml` con `observability.enabled: true`
5. **RotaciÃ³n:** Rotar tokens periÃ³dicamente
6. **SIEM integration:** Exportar traces a sistema centralizado

### Para Orquestadores

1. **No secrets en .raise/:** Usar variables de entorno
2. **Revisar guardrails:** Entender quÃ© guardrails se aplican
3. **Actualizar:** Mantener raise-kit actualizado
4. **Revisar escalations:** No ignorar Escalation Gates
5. **Auditar regularmente:** `raise audit --summary weekly`

### ConfiguraciÃ³n de Seguridad Recomendada

```yaml
# raise.yaml - Hardened config
security:
  secrets_detection: true
  guardrail_enforcement: strict  # block, not warn
  mcp:
    localhost_only: true
    max_token_output: 10000
    
observability:
  enabled: true
  traces:
    retention_days: 180
    include_content: false  # Solo hashes, no contenido
  anomaly_detection: true
  
escalation:
  require_for_gates: [gate-deploy, gate-security]
  timeout_minutes: 60
```

---

## Changelog

### v2.1.0 (2025-12-28)
- TerminologÃ­a: rules â†’ guardrails
- NUEVO: SecciÃ³n completa Observable Workflow para Compliance
- NUEVO: Vector de amenaza MCP server compromise
- NUEVO: EU AI Act alignment detallado por artÃ­culo
- NUEVO: Inmutabilidad de traces con hash chain
- NUEVO: Comandos de forensics
- NUEVO: Hardened config ejemplo
- Activos crÃ­ticos: aÃ±adido Observable Traces
- Audit trail expandido con eventos MCP

---

*Este documento se revisa trimestralmente o con cada incident. Referencias: [10-system-architecture.md](./10-system-architecture.md), [12-integration-patterns.md](./12-integration-patterns.md).*
